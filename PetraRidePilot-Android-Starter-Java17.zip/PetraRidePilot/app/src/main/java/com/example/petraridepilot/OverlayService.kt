package com.example.petraridepilot

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var calibrationView: View? = null
    private var calibrationStep = 0
    private var leftX = -1f
    private var leftY = -1f
    private var rightX = -1f
    private var rightY = -1f

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        leftX = getSharedPreferences("controls", MODE_PRIVATE).getFloat("leftX", -1f)
        leftY = getSharedPreferences("controls", MODE_PRIVATE).getFloat("leftY", -1f)
        rightX = getSharedPreferences("controls", MODE_PRIVATE).getFloat("rightX", -1f)
        rightY = getSharedPreferences("controls", MODE_PRIVATE).getFloat("rightY", -1f)
        showPanel()
    }

    private fun lp(type: Int, flags: Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 100 }

    private fun overlayType() =
        if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(0xDD17202A.toInt())
        }
        box.addView(TextView(this).apply {
            text = "PR Pilot"
            setTextColor(Color.WHITE)
            textSize = 16f
        })
        box.addView(button("معايرة الكبسات") { startCalibration() })
        box.addView(button("اختبار يسار") { testTap(leftX, leftY, "يسار") })
        box.addView(button("اختبار يمين") { testTap(rightX, rightY, "يمين") })
        box.addView(button("إخفاء اللوحة") { stopSelf() })
        panel = box
        wm.addView(box, lp(overlayType()))
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun startCalibration() {
        if (calibrationView != null) return
        calibrationStep = 0
        val screen = TextView(this).apply {
            text = "المعايرة 1/2\\nالمس مكان كبسة اليسار داخل اللعبة"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(0x99000000.toInt())
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    val loc = IntArray(2)
                    getLocationOnScreen(loc)
                    val x = event.rawX
                    val y = event.rawY
                    if (calibrationStep == 0) {
                        leftX = x; leftY = y
                        calibrationStep = 1
                        text = "المعايرة 2/2\\nالمس مكان كبسة اليمين داخل اللعبة"
                    } else {
                        rightX = x; rightY = y
                        getSharedPreferences("controls", MODE_PRIVATE).edit()
                            .putFloat("leftX", leftX).putFloat("leftY", leftY)
                            .putFloat("rightX", rightX).putFloat("rightY", rightY).apply()
                        removeCalibration()
                        Toast.makeText(this@OverlayService, "انحفظت مواقع الكبسات", Toast.LENGTH_LONG).show()
                    }
                }
                true
            }
        }
        calibrationView = screen
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(screen, p)
    }

    private fun removeCalibration() {
        calibrationView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        calibrationView = null
    }

    private fun testTap(x: Float, y: Float, label: String) {
        if (x < 0 || y < 0) {
            Toast.makeText(this, "عاير الكبسات أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        val service = GameAccessibilityService.instance
        if (service == null) {
            Toast.makeText(this, "فعّل خدمة التحكم من إعدادات إمكانية الوصول", Toast.LENGTH_LONG).show()
            return
        }
        service.tapAt(x, y) {
            Toast.makeText(this, "تم إرسال لمسة اختبار: $label", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        removeCalibration()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
