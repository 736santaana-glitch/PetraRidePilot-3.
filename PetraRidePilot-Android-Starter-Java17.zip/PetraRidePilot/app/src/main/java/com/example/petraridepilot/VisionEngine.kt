package com.example.petraridepilot

/**
 * Game-specific perception/decision layer.
 *
 * TODO for the next iteration:
 * 1. Add MediaProjection screen capture with explicit user consent.
 * 2. Collect sample frames from Autostrad Petra.
 * 3. Detect the player's car, lane boundaries, oncoming traffic, coins, and shields.
 * 4. Estimate time-to-collision and only change lanes when the destination lane is safe.
 * 5. Prefer safe driving over collectibles; stop automation when confidence is low.
 *
 * No automatic driving decisions are made by this placeholder.
 */
data class Detection(
    val playerLane: Int? = null,
    val occupiedLanes: Set<Int> = emptySet(),
    val coinLanes: Set<Int> = emptySet(),
    val shieldLanes: Set<Int> = emptySet(),
    val confidence: Float = 0f
)

enum class DrivingAction { LEFT, RIGHT, HOLD, STOP }

object VisionEngine {
    fun decide(detection: Detection): DrivingAction {
        if (detection.confidence < 0.8f || detection.playerLane == null) {
            return DrivingAction.STOP
        }
        // Deliberately fail-safe until a validated game-specific detector is added.
        return if (detection.playerLane in detection.occupiedLanes) {
            DrivingAction.STOP
        } else {
            DrivingAction.HOLD
        }
    }
}
