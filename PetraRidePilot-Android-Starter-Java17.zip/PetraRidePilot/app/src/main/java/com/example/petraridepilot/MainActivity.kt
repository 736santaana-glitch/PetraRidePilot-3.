package com.example.petraridepilot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 32, 28, 24)
        }

        val title = TextView(this).apply {
            text = "Petra Ride Pilot · Prototype"
            textSize = 24f
        }
        val intro = TextView(this).apply {
            text = "\\nمرحبا يا معلم! هاي نسخة أولية لمعايرة كبسات اللعبة وتجربة اللمس.\\n\\n" +
                "مهم: النسخة الحالية لا تكتشف السيارات أو المكافآت ولا تقود تلقائياً بعد. " +
                "بنضيف الذكاء البصري بعد ما نشوف اللعبة ونتأكد من طريقة التقاط الشاشة.\\n"
            textSize = 16f
        }
        layout.addView(title)
        layout.addView(intro)

        layout.addView(makeButton("1) تفعيل خدمة التحكم") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(makeButton("2) السماح بالظهور فوق التطبيقات") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "الإذن مفعّل", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(makeButton("3) تشغيل لوحة التحكم العائمة") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "تم طلب تشغيل اللوحة", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(makeButton("إيقاف لوحة التحكم") {
            stopService(Intent(this, OverlayService::class.java))
        })

        setContentView(layout)
    }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 }
        }
}
