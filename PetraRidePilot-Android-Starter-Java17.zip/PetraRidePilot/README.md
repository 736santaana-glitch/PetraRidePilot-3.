# Petra Ride Pilot — Android prototype

This is a starter Android Studio project for a user-calibrated driving-game helper.
It is **not a finished autonomous bot**. It provides:
- A setup screen with accessibility-service instructions.
- A floating overlay service.
- A calibration mode where you tap the game's left and right controls and save their screen coordinates.
- A safe test panel to send a single tap to each saved coordinate.
- A placeholder vision/decision module where game-specific detection must be implemented and tested.

## Requirements
- Android Studio (recent stable version)
- Android SDK 35
- A physical Android device is recommended for testing
- Android may require you to manually enable the accessibility service in Settings.

## Build and install
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the debug APK on your HMD phone.
5. Open the app and follow the Accessibility setup prompt.
6. Grant overlay permission when prompted.
7. Start the floating panel, open Petra Ride, then enter calibration mode.
8. Tap the actual left control when asked, then the right control. Coordinates are saved locally.
9. Return to the floating panel and test each control one tap at a time.

## Important limitations
- This prototype does not yet recognize cars, coins, or shields and does not automatically drive.
- A screenshot/video of the game is needed to build and validate a vision detector. Different games have different graphics, animations, and layouts; blindly auto-tapping could crash the car or waste attempts.
- Android's screen-capture permission and foreground-service requirements must be implemented before live visual detection can be added.
- Check Petra Ride's game rules before using automation to collect points.
- Use only for a game where automation is permitted. No guarantee of compatibility or points.
